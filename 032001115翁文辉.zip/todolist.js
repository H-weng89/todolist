

//光标 a
 h = document.getElementsByTagName('h1')[0]
a = -100
setInterval(() => {
    a+=5
    h.style.backgroundPosition = a+'px'+' '+0
   
    
   
    
    
}, 30);

alert('使用指南:打开导航，指针停留图片查看功能')



//导？航 flag c
//添加
var marginB = 20
var paddingT = 5

function add(){
    
    var text = prompt('请输入要添加的事件')
    if(text){
        marginB+=40
        paddingT+=40  
        
        var ol = document.querySelector('.prepare ol')
        var prepare = document.querySelector('.prepare')
        var end = document.querySelector('.end')
        var count = document.querySelector('.prepare .count')
        ol.innerHTML +='<li style = "margin-top:20px;margin-bottom:20px;">'+text+'</li>'
        // prepare.style.marginBottom = marginB+'px'
        // end.style.paddingTop = paddingT+'px'
        count.innerText++ 
        





    }

}
var addbt = document.querySelector('.wra .add')
addbt.addEventListener('click',add)
//删除


function dele() {
    var count = document.querySelector('.prepare .count')

    function deleli() {
       
        this.remove()
        // marginB-=40
        // paddingT-=40
       
        // prepare.style.marginBottom = marginB+'px'
        // end.style.paddingTop = paddingT+'px'
        count.innerText--
        document.body.style.cursor = 'default'
        for(var i = 0;i<liList.length;i++){
            liList[i].removeEventListener('click',deleli)
        }
        


        
       
         }




   
        prepare = document.querySelector('.prepare')
         end = document.querySelector('.end')
    var liList = document.getElementsByTagName('li')
  
    for(var i =0;i<liList.length;i++){
        liList[i].addEventListener('click',deleli)
      
                

    }
   
   
        document.body.style.cursor = 'pointer'} 
        
  
var delebt = document.querySelector('.wra .delet')
delebt.addEventListener('click',dele)


//已完成
conuntEnd = 0

 function ended() {
    var end = document.querySelector('end')
    var prepareCount = document.querySelector('.prepare .count')
    var endCount = document.querySelector('.end .count')
    var prepareLi = document.getElementsByTagName('li')
        var endOl = document.getElementsByTagName('ol')[1]
        var key = 1
 function endli() {
     if(key == 1){
        var text = this.innerText
        endOl.innerHTML += '<li style = "margin-top:20px;margin-bottom:20px;">'+text+'</li>'
        this.remove()
        conuntEnd++
        endCount.innerText = conuntEnd
        prepareCount.innerText-=1 
        document.body.style.cursor = 'default'
        key = 0
      }
       
      
      }

      for(var i = 0;i<prepareLi.length;i++){
          prepareLi[i].addEventListener('click',endli)
        
         
      }
      document.body.style.cursor = 'pointer'


  }
 
  var endbt = document.getElementsByClassName('finish')[0]
  endbt.addEventListener('click',ended)
  

  //编辑
  function edit()  { 
      var liList = document.getElementsByTagName('li')
      function editli() {
          text = prompt('请输入修改后的事件')
          this.innerText = text
          document.body.style.cursor = 'default'
          for(var i = 0;i<liList.length;i++){
              liList[i].removeEventListener('click',editli)

          }

        }
        document.body.style.cursor = 'pointer'
        for(var i = 0;i<liList.length;i++){
            liList[i].addEventListener('click',editli)
        }


    


  } 
  var edibt = document.querySelector('.wra .edit')
  edibt.addEventListener('click',edit)


 





//导航总体
       homeElem = document.getElementsByClassName('home')[0]
        var setElem = document.getElementsByTagName('img')
        flag = true
        var c = 140
        //点击效果
        function fn(){
            this.style.transform = 'rotate(-720deg) scale(1)'
            this.style.opacity = '1'
            


        }
        for(var i = 0;i<setElem.length;i++){
            setElem[i].onclick = function(){
                this.style.transition = '0.5s'
                this.style.transform = 'rotate(-720deg) scale(2)'
                this.style.opacity = '0.1'
                this.addEventListener('transitionend',fn)
    

            }
        }
       //扇形效果
        homeElem.onclick = function(){
            if(flag == true){
            homeElem.style.transform = 'rotate(-720deg) scale(1)'
            for(var i = 0;i<setElem.length;i++){
                setElem[i].style.transition = '1s '+(i*0.15)+'s'
                setElem[i].style.left = -getxy(c,90*i/(setElem.length-1)).left+'px'
                setElem[i].style.top = -getxy(c,90*i/(setElem.length-1)).top+'px'
                setElem[i].style.transform = 'rotate(-720deg) scale(1)'

            }
            flag = false}
            else{
                homeElem.style.transform = 'rotate(0deg) scale(1)'
                for(var i = 0;i<setElem.length;i++){
                setElem[i].style.transition = '1s '+((setElem.length-i)*0.15)+'s'
                setElem[i].style.left = 0+'px'
                setElem[i].style.top = 0+'px'
                setElem[i].style.transform = 'rotate(0deg) scale(1)'}

                flag = true

            }
            function getxy(c,deg){
                x = c*Math.sin(deg*Math.PI/180)
                 y = c*Math.cos(deg*Math.PI/180)
                 return {left:x,top:y}
            }

        } 


